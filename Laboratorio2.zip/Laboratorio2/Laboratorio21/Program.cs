﻿using System;
using System.Threading.Tasks.Sources;
using static Laboratorio21.Program;



namespace Laboratorio21
{
    public class Program
    {
        public static void main()

        {

            //Asignando valor a variable estatica
            MyClass.Valor = 1;
            Console.WriteLine(MyClass.Valor);


        }
        public class MyClass
        {
            // Declarando Variable estática

            public static int Valor;

        }


    }

    // PARTE 3

    int nombreVariable = 1000;
    int valor1 = 28;
    valor2 = valor1;
    valor1 = 30;


     Console.WriteLine(valor1);
     Console.WriteLine(valor2);
     Console.WriteLine(valor1);
     Console.WriteLine(valor2);


    MyClass object1 = new MyClass();  //creando una nueva instancia
    object1.Nombre = "Fulano";
    object1.Edad = 28;
    MyClass object2 = object1;  // Asignando una variable a otra


    MyClass object1 = new MyClass();  //creando una nueva instancia
    object1.Nombre = "Yeison";
    object1.Edad = 28;

    // Asignando una variable a otra
     MyClass object2 = object1;  // Asignando una variable a otra

    //este cambio en la propiedad afecta tanto a object1 como a object2
    object2.Nombre = "José";

    // al imprimir en consola vemos que ambas referencias imprimen el mismo valor José

    Console.WriteLine(object2.Nombre);
    Console.WriteLine(object1.Nombre);


    //Tipos de datos alfanumericos
    char caracter = 'A';
    string cadena = "cadena de caracteres"; //variable almacenada en una cadena de caracteres.

    bool condicion = true;









